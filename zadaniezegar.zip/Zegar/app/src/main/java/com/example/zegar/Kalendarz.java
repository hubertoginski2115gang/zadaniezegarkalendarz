package com.example.zegar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.lang.reflect.Array;

public class Kalendarz extends AppCompatActivity {
    Button button;
    int index = 0;
    String tab[] = new String[11];
    TextView tekst = findViewById(R.id.textView14);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_kalendarz);
        Button button = (Button) findViewById(R.id.button);

        tab[0] = "Styczeń 2024";
        tab[1] = "Luty 2024";
        tab[2] = "Marczec 2024";
        tab[3] = "Kwiecien 2024";
        tab[4] = "Maj 2024";
        tab[5] = "Czerwiec 2024";
        tab[6] = "Lipiec 2024";
        tab[7] = "Sierpien 2024";
        tab[8] = "Wrzesien 2024";
        tab[9] = "Pazdziernik 2024";
        tab[10] = "Listopad 2024";
        tab[11] = "Grudzien 2024";
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity();
            }
        });


        Button buttonDalej = (Button) findViewById(R.id.button4);
        buttonDalej.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index++;
                tekst.setText(tab[index]);
            }



        });

    }
    public void openNewActivity(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
